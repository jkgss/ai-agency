import { useState } from 'react';
import { CheckCircle2, ArrowRight } from 'lucide-react';

export default function AuditSection() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: '',
    message: ''
  });

  const benefits = [
    'Analysis of your existing processes and tools',
    'Identification of high-impact automation possibilities',
    'Clear recommendations prioritized by effort and impact',
    'Actionable next steps, whether you work with us or not'
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Form submitted:', formData);
  };

  return (
    <section id="audit" className="py-32 px-6 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[rgba(74,144,226,0.05)] to-transparent pointer-events-none" />
      <div className="max-w-5xl mx-auto relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-8">
            Free Automation Audit
          </h2>
          <p className="text-xl text-gray-300 mb-6 leading-relaxed" style={{ lineHeight: '1.6' }}>
            A comprehensive review of your current workflows with specific automation opportunities identified.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-12 items-start">
          <div className="space-y-6 animate-fade-in">
            <h3 className="text-2xl font-semibold text-white mb-8">
              What You'll Receive:
            </h3>
            <ul className="space-y-5">
              {benefits.map((benefit, index) => (
                <li key={index} className="flex gap-4 items-start">
                  <CheckCircle2 className="w-6 h-6 text-[#4a90e2] flex-shrink-0 mt-1" />
                  <span className="text-lg text-gray-300 leading-relaxed" style={{ lineHeight: '1.6' }}>
                    {benefit}
                  </span>
                </li>
              ))}
            </ul>
            <p className="text-lg text-[#4a90e2] font-semibold mt-8 italic">
              This audit provides value regardless of any future engagement.
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6 animate-fade-in">
            <div>
              <label htmlFor="name" className="block text-gray-300 mb-2 text-sm font-medium">
                Name
              </label>
              <input
                type="text"
                id="name"
                required
                className="w-full px-4 py-3 bg-[#1a1a1a] border border-gray-700 rounded-sm text-white placeholder-gray-500 focus:outline-none focus:border-[#4a90e2] focus:bg-[#0f0f0f] transition-all duration-200"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="Your name"
              />
            </div>
            <div>
              <label htmlFor="email" className="block text-gray-300 mb-2 text-sm font-medium">
                Email
              </label>
              <input
                type="email"
                id="email"
                required
                className="w-full px-4 py-3 bg-[#1a1a1a] border border-gray-700 rounded-sm text-white placeholder-gray-500 focus:outline-none focus:border-[#4a90e2] focus:bg-[#0f0f0f] transition-all duration-200"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                placeholder="you@company.com"
              />
            </div>
            <div>
              <label htmlFor="company" className="block text-gray-300 mb-2 text-sm font-medium">
                Company
              </label>
              <input
                type="text"
                id="company"
                required
                className="w-full px-4 py-3 bg-[#1a1a1a] border border-gray-700 rounded-sm text-white placeholder-gray-500 focus:outline-none focus:border-[#4a90e2] focus:bg-[#0f0f0f] transition-all duration-200"
                value={formData.company}
                onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                placeholder="Your company"
              />
            </div>
            <div>
              <label htmlFor="message" className="block text-gray-300 mb-2 text-sm font-medium">
                Tell us about your operations
              </label>
              <textarea
                id="message"
                rows={4}
                required
                className="w-full px-4 py-3 bg-[#1a1a1a] border border-gray-700 rounded-sm text-white placeholder-gray-500 focus:outline-none focus:border-[#4a90e2] focus:bg-[#0f0f0f] transition-all duration-200 resize-none"
                value={formData.message}
                onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                placeholder="What's your biggest operational challenge?"
              />
            </div>
            <button
              type="submit"
              className="group w-full bg-[#4a90e2] hover:bg-[#3a7bc8] text-white px-8 py-4 text-lg font-semibold rounded-sm transition-all duration-300 inline-flex items-center justify-center gap-3 shadow-lg hover:shadow-xl hover:scale-105"
            >
              Request Your Audit
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </button>
          </form>
        </div>
      </div>
    </section>
  );
}
