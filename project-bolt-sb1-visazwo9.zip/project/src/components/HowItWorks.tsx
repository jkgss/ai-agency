import { Search, Target, Cog, MessageSquare } from 'lucide-react';

export default function HowItWorks() {
  const steps = [
    {
      number: '1',
      icon: Search,
      title: 'Understand Your Current System',
      description: 'We map your existing workflows, tools, and team processes to identify how work actually gets done.'
    },
    {
      number: '2',
      icon: Target,
      title: 'Identify Bottlenecks and Waste',
      description: 'Together, we pinpoint where time is lost, where errors occur, and where manual work creates unnecessary friction.'
    },
    {
      number: '3',
      icon: Cog,
      title: 'Design Practical Automations',
      description: 'We develop automation solutions that integrate with your current operations—no rip-and-replace required.'
    },
    {
      number: '4',
      icon: MessageSquare,
      title: 'Decide Together What Makes Sense',
      description: 'You receive clear recommendations with implementation options. Every decision stays with you.'
    }
  ];

  return (
    <section className="py-32 px-6 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-[rgba(74,144,226,0.04)] via-transparent to-[rgba(74,144,226,0.02)] pointer-events-none" />
      <div className="max-w-5xl mx-auto relative z-10">
        <h2 className="text-4xl md:text-5xl font-bold text-white mb-20 text-center">
          How we approach this
        </h2>

        <div className="space-y-16">
          {steps.map((step, index) => (
            <div
              key={index}
              className="flex gap-8 items-start group animate-fade-in hover:translate-x-2 transition-transform duration-300"
            >
              <div className="flex-shrink-0">
                <div className="w-16 h-16 rounded-sm bg-[#4a90e2] bg-opacity-10 flex items-center justify-center border border-[#4a90e2] border-opacity-30 group-hover:bg-opacity-20 transition-all">
                  <step.icon className="w-8 h-8 text-[#4a90e2]" />
                </div>
              </div>
              <div className="flex-1 pt-2">
                <div className="flex items-center gap-4 mb-4">
                  <span className="text-5xl font-bold text-gray-700">{step.number}</span>
                  <h3 className="text-2xl font-semibold text-white" style={{ lineHeight: '1.2' }}>
                    {step.title}
                  </h3>
                </div>
                <p className="text-lg text-gray-300 leading-relaxed" style={{ lineHeight: '1.6' }}>
                  {step.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
