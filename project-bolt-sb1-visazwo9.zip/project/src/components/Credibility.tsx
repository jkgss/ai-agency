import { Award, Zap, Building2, TrendingUp } from 'lucide-react';

export default function Credibility() {
  const stats = [
    {
      icon: Award,
      number: '8+',
      label: 'years building systems and analyzing operational data'
    },
    {
      icon: Zap,
      number: '200+',
      label: 'automations running in production environments'
    },
    {
      icon: Building2,
      number: 'Multiple',
      label: 'industries including manufacturing, professional services, and technology'
    },
    {
      icon: TrendingUp,
      number: 'Systems-first',
      label: 'approach focused on sustainable operational improvement'
    }
  ];

  return (
    <section className="py-32 px-6 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[rgba(74,144,226,0.03)] to-transparent pointer-events-none" />
      <div className="max-w-6xl mx-auto relative z-10">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12">
          {stats.map((stat, index) => (
            <div
              key={index}
              className="text-center group animate-fade-in hover:scale-105 transition-transform duration-300"
            >
              <div className="mb-6 flex justify-center">
                <div className="w-16 h-16 rounded-sm bg-[#4a90e2] bg-opacity-10 flex items-center justify-center border border-[#4a90e2] border-opacity-30 group-hover:bg-opacity-20 transition-all">
                  <stat.icon className="w-8 h-8 text-[#4a90e2]" />
                </div>
              </div>
              <div className="text-3xl font-bold text-white mb-3">
                {stat.number}
              </div>
              <p className="text-gray-400 leading-relaxed" style={{ lineHeight: '1.6' }}>
                {stat.label}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
