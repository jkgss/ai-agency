import { CheckCircle2, XCircle } from 'lucide-react';

export default function WhoThisIsFor() {
  const forYou = [
    'Real operations with repeating processes',
    'Teams spending hours on manual, routine work',
    'Multiple tools that don\'t communicate effectively',
    'Founders who want clarity before making technology investments',
    'Established workflows that could run more efficiently'
  ];

  const notForYou = [
    'Businesses seeking instant transformation or "magic button" solutions',
    'Hobby projects or early-stage experiments',
    'Teams expecting results without process changes',
    'Organizations unwilling to examine current operations',
    'Anyone looking for AI novelty rather than operational improvement'
  ];

  return (
    <section className="py-32 px-6 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[rgba(74,144,226,0.03)] to-transparent pointer-events-none" />
      <div className="max-w-6xl mx-auto relative z-10">
        <h2 className="text-4xl md:text-5xl font-bold text-white mb-20 text-center">
          This is for you if you recognize yourself here
        </h2>

        <div className="grid md:grid-cols-2 gap-12 md:gap-16">
          <div className="space-y-6 animate-fade-in">
            <div className="flex items-center gap-3 mb-8">
              <CheckCircle2 className="w-8 h-8 text-green-500" />
              <h3 className="text-2xl font-semibold text-white">This is for you</h3>
            </div>
            <ul className="space-y-5">
              {forYou.map((item, index) => (
                <li key={index} className="text-lg text-gray-300 leading-relaxed" style={{ lineHeight: '1.6' }}>
                  {item}
                </li>
              ))}
            </ul>
          </div>

          <div className="space-y-6 animate-fade-in md:border-l md:border-gray-700 md:pl-16">
            <div className="flex items-center gap-3 mb-8">
              <XCircle className="w-8 h-8 text-red-500" />
              <h3 className="text-2xl font-semibold text-white">This isn't for you</h3>
            </div>
            <ul className="space-y-5">
              {notForYou.map((item, index) => (
                <li key={index} className="text-lg text-gray-300 leading-relaxed" style={{ lineHeight: '1.6' }}>
                  {item}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}
