import { ArrowRight } from 'lucide-react';

export default function Hero() {
  const scrollToAudit = () => {
    document.getElementById('audit')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="min-h-screen flex items-center justify-center px-6 relative">
      {/* Section-specific gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-b from-[rgba(74,144,226,0.05)] via-transparent to-transparent pointer-events-none" />

      <div className="max-w-4xl mx-auto text-center animate-fade-in relative z-10">
        <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold text-white mb-8 leading-tight">
          Your operations shouldn't feel like constant firefighting
        </h1>
        <p className="text-xl md:text-2xl text-gray-300 mb-12 leading-relaxed max-w-3xl mx-auto" style={{ lineHeight: '1.6' }}>
          AI automation isn't magic—it's systematic problem-solving. We help established businesses eliminate operational friction through practical, proven automation systems.
        </p>
        <button
          onClick={scrollToAudit}
          className="group bg-white hover:bg-[#4a90e2] text-[#0f0f0f] hover:text-white px-10 py-5 text-lg font-semibold rounded-sm transition-all duration-300 inline-flex items-center gap-3 shadow-lg hover:shadow-2xl hover:scale-105"
        >
          Request an Automation Audit
          <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
        </button>
      </div>
    </section>
  );
}
