import { Phone, Search, FileText, CheckSquare } from 'lucide-react';

export default function WhatHappensNext() {
  const steps = [
    {
      icon: Phone,
      title: 'Brief intro call',
      description: '(30 minutes) to understand your operations'
    },
    {
      icon: Search,
      title: 'No sales presentation',
      description: 'just questions about how your business works'
    },
    {
      icon: FileText,
      title: 'Clear recommendations',
      description: 'delivered within one week'
    },
    {
      icon: CheckSquare,
      title: 'You decide',
      description: 'what makes sense for your business'
    }
  ];

  return (
    <section className="py-32 px-6 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[rgba(74,144,226,0.03)] to-transparent pointer-events-none" />
      <div className="max-w-5xl mx-auto relative z-10">
        <h2 className="text-4xl md:text-5xl font-bold text-white mb-8 text-center">
          What Happens Next
        </h2>
        <p className="text-xl text-gray-300 mb-16 text-center">
          After You Submit:
        </p>

        <div className="grid md:grid-cols-2 gap-8">
          {steps.map((step, index) => (
            <div
              key={index}
              className="flex gap-6 items-start p-8 bg-gradient-to-br from-[#1a1a1a] to-[#0f0f0f] border border-gray-800 rounded-sm hover:border-[#4a90e2] hover:border-opacity-50 transition-all duration-300 animate-fade-in hover:scale-105 hover:shadow-lg hover:shadow-[rgba(74,144,226,0.1)]"
            >
              <div className="flex-shrink-0">
                <div className="w-14 h-14 rounded-sm bg-[#4a90e2] bg-opacity-10 flex items-center justify-center border border-[#4a90e2] border-opacity-30">
                  <step.icon className="w-7 h-7 text-[#4a90e2]" />
                </div>
              </div>
              <div>
                <h3 className="text-xl font-semibold text-white mb-2" style={{ lineHeight: '1.2' }}>
                  {step.title}
                </h3>
                <p className="text-gray-400 leading-relaxed" style={{ lineHeight: '1.6' }}>
                  {step.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
