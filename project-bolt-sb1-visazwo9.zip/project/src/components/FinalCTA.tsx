import { ArrowRight } from 'lucide-react';

export default function FinalCTA() {
  const scrollToAudit = () => {
    document.getElementById('audit')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="py-32 px-6 bg-gradient-to-b from-[#0f0f0f] to-[#1a1a1a]">
      <div className="max-w-4xl mx-auto text-center">
        <h2 className="text-4xl md:text-5xl font-bold text-white mb-8">
          Ready to See What's Possible?
        </h2>
        <p className="text-xl md:text-2xl text-gray-300 mb-12 leading-relaxed" style={{ lineHeight: '1.6' }}>
          Get a clear picture of your automation opportunities with our free operational audit.
        </p>
        <button
          onClick={scrollToAudit}
          className="group bg-[#4a90e2] hover:bg-[#3a7bc8] text-white px-10 py-5 text-lg font-semibold rounded-sm transition-all duration-300 inline-flex items-center gap-3 shadow-lg hover:shadow-xl hover:scale-105"
        >
          Request an Automation Audit
          <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
        </button>
      </div>
    </section>
  );
}
