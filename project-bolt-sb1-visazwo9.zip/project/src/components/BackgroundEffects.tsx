import { useEffect, useState } from 'react';

export default function BackgroundEffects() {
  const [scrollPosition, setScrollPosition] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      setScrollPosition(window.scrollY);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <>
      <div className="fixed inset-0 overflow-hidden pointer-events-none -z-10">
        {/* Base gradient background */}
        <div className="absolute inset-0 bg-gradient-to-br from-[#0f0f0f] via-[#1a1a1a] to-[#0f0f0f]" />

        {/* Animated gradient orb 1 - Top left */}
        <div
          className="absolute top-0 -left-1/4 w-96 h-96 rounded-full blur-3xl animate-float"
          style={{
            background: 'radial-gradient(circle, rgba(74, 144, 226, 0.15) 0%, rgba(74, 144, 226, 0) 70%)',
            transform: `translateY(${scrollPosition * 0.5}px)`,
          }}
        />

        {/* Animated gradient orb 2 - Top right */}
        <div
          className="absolute -top-1/3 -right-1/4 w-[600px] h-[600px] rounded-full blur-3xl"
          style={{
            background: 'radial-gradient(circle, rgba(74, 144, 226, 0.1) 0%, rgba(74, 144, 226, 0) 70%)',
            animation: 'float 8s ease-in-out infinite',
            animationDelay: '-2s',
            transform: `translateY(${scrollPosition * 0.3}px)`,
          }}
        />

        {/* Animated gradient orb 3 - Bottom center */}
        <div
          className="absolute -bottom-1/4 left-1/2 transform -translate-x-1/2 w-[700px] h-[700px] rounded-full blur-3xl"
          style={{
            background: 'radial-gradient(circle, rgba(74, 144, 226, 0.08) 0%, rgba(74, 144, 226, 0) 70%)',
            animation: 'float 10s ease-in-out infinite',
            animationDelay: '-4s',
            transform: `translateY(${scrollPosition * 0.4}px) translateX(-50%)`,
          }}
        />

        {/* Grid accent - subtle */}
        <div
          className="absolute inset-0 opacity-5"
          style={{
            backgroundImage: `
              linear-gradient(0deg, transparent 24%, rgba(74, 144, 226, 0.1) 25%, rgba(74, 144, 226, 0.1) 26%, transparent 27%, transparent 74%, rgba(74, 144, 226, 0.1) 75%, rgba(74, 144, 226, 0.1) 76%, transparent 77%, transparent),
              linear-gradient(90deg, transparent 24%, rgba(74, 144, 226, 0.1) 25%, rgba(74, 144, 226, 0.1) 26%, transparent 27%, transparent 74%, rgba(74, 144, 226, 0.1) 75%, rgba(74, 144, 226, 0.1) 76%, transparent 77%, transparent)
            `,
            backgroundSize: '80px 80px',
          }}
        />

        {/* Accent lines for visual structure */}
        <div className="absolute top-1/4 left-0 w-full h-px bg-gradient-to-r from-transparent via-[rgba(74,144,226,0.1)] to-transparent" />
        <div className="absolute top-1/2 left-0 w-full h-px bg-gradient-to-r from-transparent via-[rgba(74,144,226,0.05)] to-transparent" />
        <div className="absolute top-3/4 left-0 w-full h-px bg-gradient-to-r from-transparent via-[rgba(74,144,226,0.1)] to-transparent" />
      </div>
    </>
  );
}
