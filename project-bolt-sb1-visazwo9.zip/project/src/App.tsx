import Hero from './components/Hero';
import WhoThisIsFor from './components/WhoThisIsFor';
import HowItWorks from './components/HowItWorks';
import Credibility from './components/Credibility';
import AuditSection from './components/AuditSection';
import WhatHappensNext from './components/WhatHappensNext';
import FinalCTA from './components/FinalCTA';
import BackgroundEffects from './components/BackgroundEffects';

function App() {
  return (
    <div className="min-h-screen bg-[#0f0f0f] relative">
      <BackgroundEffects />
      <div className="relative z-0">
        <Hero />
        <WhoThisIsFor />
        <HowItWorks />
        <Credibility />
        <AuditSection />
        <WhatHappensNext />
        <FinalCTA />
      </div>
    </div>
  );
}

export default App;
